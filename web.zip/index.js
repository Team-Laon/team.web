const express = require('express')
const app = express();
const fs = require('fs')
app.get('/', async (req, res) => {
    const file = fs.readFileSync("./index.html", { encoding: 'utf-8' })

    res.send(file)
})
app.get('/hello', (req, res) => {
    res.send('hello world')
})

app.use('/assets', express.static('assets'))

app.listen(8888, () => console.log('Web Server Port 8888'))